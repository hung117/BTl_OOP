package uet.oop.bomberman.Level;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.entities.Environment.Destroyable.Brick;
import uet.oop.bomberman.entities.Environment.Grass;
import uet.oop.bomberman.entities.Environment.Portal;
import uet.oop.bomberman.entities.Environment.Wall;
import uet.oop.bomberman.entities.LayeredEntity;
import uet.oop.bomberman.entities.enemy.Balloon;
import uet.oop.bomberman.entities.enemy.Oneal;
import uet.oop.bomberman.entities.items.FlameItem;
import uet.oop.bomberman.entities.items.bombItem;
import uet.oop.bomberman.entities.items.speedIncrease_Item;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Screen;
import uet.oop.bomberman.graphics.Sprite;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;

public class FileLevelLoader extends LevelLoader {

    private static char[][] _map;

    public FileLevelLoader(Board board, int level) {
        super(board, level);
    }

    @Override
    public void loadLevel(int level) {
        BufferedReader br = null;
        URL Path = FileLevelLoader.class.getResource("/levels/Level" + level + ".txt");
        //URL Path = FileLevelLoader.class.getResource("/levels/Level2.txt");
        try {
            br = new BufferedReader(new InputStreamReader(Path.openStream()));
            String[] firstLine = br.readLine().split(" ");
            _level = Integer.parseInt(firstLine[0]);
            _height = Integer.parseInt(firstLine[1]);
            _width = Integer.parseInt(firstLine[2]);

            _map = new char[_height][_width];
            String line;
            for (int i = 0; i < _height; i++) {
                line = br.readLine();
                for (int j = 0; j < _width; j++) _map[i][j] = line.charAt(j);
            }
        } catch (IOException e) {

        } finally {
            try {
                br.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void createEntities() {
        for (int y = 0; y < getHeight(); y++) {
            for (int x = 0; x < getWidth(); x++) {
                addEntities(_map[y][x], x, y);
            }
        }
    }

    public void addEntities(char c, int x, int y) {
        int pos = x + y * getWidth();

        switch (c) {
            // thêm Wall
            case '#':
                _board.addEntity(pos, new Wall(x, y, Sprite.wall));
                break;
            // thêm Item
            case 'b':
                _board.addEntity(pos,
                        new LayeredEntity(x, y,
                                new Grass(x ,y, Sprite.grass),
                                new bombItem(x, y, Sprite.powerup_bombs,_board),
                                new Brick(x, y, Sprite.brick)
                        )
                );
                break;

            case 's':
                _board.addEntity(pos,
                        new LayeredEntity(x, y,
                                new Grass(x ,y, Sprite.grass),
                                new speedIncrease_Item(x, y, Sprite.powerup_speed,_board),
                                new Brick(x, y, Sprite.brick)
                        )
                );
                break;

            case 'f':
                _board.addEntity(pos,
                        new LayeredEntity(x, y,
                                new Grass(x ,y, Sprite.grass),
                                new FlameItem(x, y, Sprite.powerup_flames,_board),
                                new Brick(x, y, Sprite.brick)
                        )
                );
                break;

            // thêm Brick
            case '*':
                _board.addEntity(pos, new LayeredEntity(x, y,
                        new Grass(x ,y, Sprite.grass),
                        new Brick(x ,y, Sprite.brick)) );
                break;
            // thêm Portal
            case 'x':
                _board.addEntity(pos, new LayeredEntity(x, y,
                        new Grass(x ,y, Sprite.grass),
                        new Portal(x ,y, _board, Sprite.portal),
                        new Brick(x ,y, Sprite.brick)) );
                break;
            // thêm Grass
            case ' ':
                _board.addEntity(pos, new Grass(x, y, Sprite.grass));
                break;
            // thêm Bomber
            case 'p':
                _board.addCharacter( new Bomber(Coordinates.tileToPixel(x), Coordinates.tileToPixel(y) + Game.TILES_SIZE, _board) );
                Screen.setOffset(0, 0);

                _board.addEntity(pos, new Grass(x, y, Sprite.grass) );
                break;
            // thêm Enemy
            case '1':
                _board.addCharacter( new Balloon(Coordinates.tileToPixel(x), Coordinates.tileToPixel(y) + Game.TILES_SIZE, _board));
                _board.addEntity(pos, new Grass(x, y, Sprite.grass) );
                break;

            case '2':
                _board.addCharacter( new Oneal(Coordinates.tileToPixel(x), Coordinates.tileToPixel(y) + Game.TILES_SIZE, _board));
                _board.addEntity(pos, new Grass(x, y, Sprite.grass) );
                break;
            default:
                _board.addEntity(pos, new Grass(x, y, Sprite.grass) );
                break;
        }
    }
}






