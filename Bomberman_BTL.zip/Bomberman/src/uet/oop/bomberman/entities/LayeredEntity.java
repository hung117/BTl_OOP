package uet.oop.bomberman.entities;

import uet.oop.bomberman.entities.Environment.Destroyable.DestroyableTile;
import uet.oop.bomberman.graphics.Screen;

import java.util.LinkedList;

public class LayeredEntity extends Entity{
        protected LinkedList<Entity> _LinkedEntity = new LinkedList<>();
        public LayeredEntity(int x, int y, Entity... entities){
            _x = x;
            _y = y;
            for(int i = 0; i < entities.length; i++){
                _LinkedEntity.add(entities[i]);
                if(i>1){
                    if(entities[i] instanceof DestroyableTile){
                        //add entity below
                        ((DestroyableTile)entities[i]).addBelowSprite(entities[i-1].getSprite());

                    }
                }
            }
        }

        public Entity getTopEntity(){
            return _LinkedEntity.getLast();
        }

        @Override
        public void update() {
            clearRemoved();
            getTopEntity().update();
        }

        @Override
        public void render(Screen screen) {
            getTopEntity().render(screen);
        }

         private void clearRemoved() {
            Entity top  = getTopEntity();

            if(top.isRemoved())  {
                _LinkedEntity.removeLast();
            }
        }

        @Override
        public boolean collide(Entity e) {
            return getTopEntity().collide(e);
        }

}