package uet.oop.bomberman.entities.Environment;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.enemy.Enemy;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Sprite;

public class Portal extends Tile {
    protected Board _board;
    public Portal(int x, int y, Board board, Sprite sprite) {
        super(x, y, sprite);
        _board = board;
    }
    @Override
    public boolean collide(Entity e) {
        /**
         * detect what bomber head to
         */
        if(e instanceof Bomber) {
            // detect enemies tren board
            if(_board.detectNoEnemies() == false)
                return false;
            // tông vào != enemies -> xử lí:
            if(e.getXTile() == getX() && e.getYTile() == getY()) {
                if(_board.detectNoEnemies())
                  //  _board.nextLevel();
                    _board.endGame();
            }

            return true;
        }
        return false;
    }
}
