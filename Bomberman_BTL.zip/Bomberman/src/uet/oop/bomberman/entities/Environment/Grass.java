package uet.oop.bomberman.entities.Environment;

import javafx.scene.image.Image;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.graphics.Sprite;

public class Grass extends Tile {

    public Grass(int x, int y, Sprite sprite) {
        super(x, y, sprite);
    }

    //let pass all character pass through
    @Override
    public boolean collide(Entity e) {
        return true;
    }
}
