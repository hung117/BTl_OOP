package uet.oop.bomberman.entities.player;

import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import uet.oop.bomberman.Board;
import uet.oop.bomberman.Control.Keyboard;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.Level.Coordinates;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.bomb.Bomb;
import uet.oop.bomberman.entities.bomb.Explosion;
import uet.oop.bomberman.entities.enemy.Enemy;
import uet.oop.bomberman.graphics.Screen;
import uet.oop.bomberman.graphics.Sprite;

import java.awt.*;
import java.util.Iterator;
import java.util.List;

public class Bomber extends Character {

    private List<Bomb> _bombs;
    protected Keyboard _input;
    protected int _timeBetweenPutBombs = 3;

    public Bomber(int x, int y, Board board) {
        super(x, y, board);
        _input = _board.getInput();
        _sprite = Sprite.player_right;
        _bombs = _board.getBombs();
    }

    @Override
    public void update() {
        clearBombs();
        if (!_alive) {
            afterKill();
            return;
        }

        if (_timeBetweenPutBombs < -7500) _timeBetweenPutBombs = 0;
        else _timeBetweenPutBombs--;

        animate();

        calculateMove();

        detectPlaceBomb();
    }

    @Override
    public void render(Screen screen) {
        calculateXOffset();
        if(_alive){
            chooseSprite();
        } else {
            _sprite = Sprite.player_dead1;
        }
        screen.renderEntity((int)_x, (int)_y - _sprite.SIZE, this);
    }

    public void calculateXOffset() {
        int xScroll = Screen.calculateXOffset(_board, this);
        Screen.setOffset(xScroll, 0);
    }

    protected void placeBomb(int x, int y){
        Bomb bomb = new Bomb(x, y, _board);
        _board.addBomb(bomb);
        Message msg = new Message("Bomb placed", getXMessage(), getYMessage(), 2, Color.yellow, 14);
        _board.addMessage(msg);
    }

    private void detectPlaceBomb(){
        if (_input.space && Game.getBombRate() > 0 && _timeBetweenPutBombs < 0) {

            int x = Coordinates.pixelToTile(_x + _sprite.getSize() / 2);
            int y = Coordinates.pixelToTile( (_y + _sprite.getSize() / 2) - _sprite.getSize() );

            placeBomb(x,y);
            Game.addBombRate(-1);

            _timeBetweenPutBombs = 30;
        }
    }

    private void clearBombs() {
        Iterator<Bomb> bs = _bombs.iterator();

        Bomb b;
        while (bs.hasNext()) {
            b = bs.next();
            if (b.isRemoved()) {
                bs.remove();
                Game.addBombRate(1);
            }
        }

    }

    @Override
    protected void calculateMove() {
        int x = 0, y = 0;
        if(_input.up) y--;
        if(_input.down) y++;
        if(_input.right) x++;
        if(_input.left) x--;

        if(x != 0 || y != 0){
            move(x * Game.getBomberSpeed(), y * Game.getBomberSpeed());
            _moving = true;
        } else {
            _moving = false;
        }
    }


    /**
     * left_3; down_2; right_1; up_0
     * @param xa
     * @param ya
     */
    @Override
    protected void move(double xa, double ya) {
        if(canMove(0, ya)) _y += ya;
        if(canMove(xa, 0)) _x += xa;
        if (_input.up) _direction = 0;
        if (_input.right) _direction = 1;
        if (_input.down) _direction = 2;
        if (_input.left) _direction = 3;
    }

    @Override
    public void killed() {
        if(!_alive) return;
        _alive = false;
        _board.addLives(-1);
        Message msg = new Message("-1 LIVE", getXMessage(), getYMessage(), 2, Color.yellow, 14);
        _board.addMessage(msg);
    }

    @Override
    protected void afterKill() {
        if(_timeAfterDead > 0) _timeAfterDead--;
        else {
            if(_bombs.size() == 0){
                if(_board.getLives() == 0){
                    _board.endGame();
                } else {
                    _board.restartLevel();
                }
            }
        }
    }

    @Override
    public boolean canMove(double x, double y) {
        for (int i = 0; i < 4; i ++) {
            //find location of the entity
            double xt = ((_x + x) + i % 2 * 11) / Game.TILES_SIZE;
            double yt = ((_y + y) + i / 2 * 12 - 13) / Game.TILES_SIZE;
            //get the entity at that location
            Entity a = _board.getEntity(xt, yt, this);

            if(!a.collide(this))
                return false;
        }

        return true;
    }

    @Override
    public boolean collide(Entity e) {
        if(e instanceof Enemy){
            killed();
            return true;
        }
        if(e instanceof Explosion){
            killed();
            return true;
        }
        return true;
    }

    public void chooseSprite(){
        switch (_direction) {
            case 0:
                _sprite = Sprite.player_up;
                if (_moving) {
                    _sprite = Sprite.movingSprite(Sprite.player_up_1, Sprite.player_up_2, _animate, 20);
                }
                break;
            case 1:
                _sprite = Sprite.player_right;
                if (_moving) {
                    _sprite = Sprite.movingSprite(Sprite.player_right_1, Sprite.player_right_2, _animate, 20);
                }
                break;
            case 2:
                _sprite = Sprite.player_down;
                if (_moving) {
                    _sprite = Sprite.movingSprite(Sprite.player_down_1, Sprite.player_down_2, _animate, 20);
                }
                break;
            case 3:
                _sprite = Sprite.player_left;
                if (_moving) {
                    _sprite = Sprite.movingSprite(Sprite.player_left_1, Sprite.player_left_2, _animate, 20);
                }
                break;
            default:
                _sprite = Sprite.player_right;
                if (_moving) {
                    _sprite = Sprite.movingSprite(Sprite.player_right_1, Sprite.player_right_2, _animate, 20);
                }
                break;
        }
    }
}
