package uet.oop.bomberman.entities.items;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Environment.Tile;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Sprite;

import java.awt.*;

public abstract class Item extends Tile {
    boolean _active = false;
    Message msg;
    Board _board;

    public Item(int x, int y, Sprite sprite, Board board) {
        super(x, y, sprite);
        _board = board;
    }

    public boolean collide(Entity e) {
        // TODO: xử lý Bomber ăn Item
        if (e instanceof Bomber) {
            // MyAudioPlayer powerUpAudio = new MyAudioPlayer(MyAudioPlayer.POWER_UP);
            //  powerUpAudio.play();
            if (!_active) {
                _active = true;
                msg = getMessage();
                _board.addMessage(msg);
            }
            remove();
            return true;
        }
        return false;
    }

    protected Message getMessage() {
        return new Message("+" + getFuction(), getXMessage(), getYMessage(), 2, Color.white, 14);
    }

    protected String getFuction() {
        return "";
    }

    protected double getXMessage() {
        return (_x * Game.SCALE) + (_sprite.SIZE / 2 * Game.SCALE);
    }

    protected double getYMessage() {
        return (_y * Game.SCALE) - (_sprite.SIZE / 2 * Game.SCALE);
    }
}
