package uet.oop.bomberman.entities.items;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.bomb.Bomb;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Sprite;

import java.awt.*;

public class FlameItem extends Item {
    public FlameItem(int x, int y, Sprite sprite, Board board) {
        super(x, y, sprite,board);
    }

    @Override
    public boolean collide(Entity e) {
        // TODO: xử lý Bomber ăn Item
        if (e instanceof Bomber) {
            if (!_active) {
                _active = true;
                Game.addBombRadius(1);
               e= (Character)e;
                Message msg = new Message("+ Flame segment", e.getX(), e.getY(), 2, Color.yellow, 14);
               _board.addMessage(msg);
/*               msg = getMessage();
               _board.addMessage(msg);*/
            }
            remove();
            return true;
        }
        return false;
    }

    @Override
    protected String getFuction() {
        return "Flame segment";
    }
}
