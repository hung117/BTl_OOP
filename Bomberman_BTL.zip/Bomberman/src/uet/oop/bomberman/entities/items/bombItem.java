package uet.oop.bomberman.entities.items;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Sprite;

import java.awt.*;

public class bombItem extends Item {
    protected boolean _active;

    public bombItem(int x, int y, Sprite sprite,Board board) {
        super(x, y, sprite, board );
        _active = false;
    }
    @Override
    public boolean collide(Entity e) {
        // TODO: xử lý Bomber ăn Item
        if(e instanceof Bomber) {
            if (!_active) {
                _active = true;
                Game.addBombRate(8);
                Message msg = new Message("+ Flame segment", getXMessage(), getYMessage(), 2, Color.yellow, 14);
                _board.addMessage(msg);
            }
            remove();
            return true;
        }

        return false;
    }
}
