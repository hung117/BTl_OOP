package uet.oop.bomberman.entities.bomb;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.enemy.Enemy;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Screen;

public class Explosion extends Entity {

    protected Board _board;
    protected int _direction;
    private int _radius;
    protected int xOrigin, yOrigin;
    protected ExplosionSegment[] _explosionSegments = new ExplosionSegment[0];

    public Explosion(int x, int y, int direction, int radius, Board board){
        xOrigin = x;
        yOrigin = y;
        _x = x;
        _y = y;
        _direction = direction;
        _radius = radius;
        _board = board;
        createExplosionSegments();
    }

    private void createExplosionSegments(){
        _explosionSegments = new ExplosionSegment[calculateDistance()];
        boolean last = false;

        //create explosion segments

        int x = (int)_x;
        int y = (int)_y;
        for (int i = 0; i < _explosionSegments.length; i++) {
            last = i == _explosionSegments.length -1 ? true : false;

            switch (_direction) {
                case 0: y--; break;
                case 1: x++; break;
                case 2: y++; break;
                case 3: x--; break;
            }
            _explosionSegments[i] = new ExplosionSegment(x, y, _direction, last);
        }
    }

    private int calculateDistance(){
        int radius = 0;
        int x = (int)_x;
        int y = (int)_y;
        while(radius < _radius) {
            if(_direction == 0) y--;
            if(_direction == 1) x++;
            if(_direction == 2) y++;
            if(_direction == 3) x--;

            Entity a = _board.getEntity(x, y, null);

            if(a instanceof Character) ++radius;

            if(!a.collide(this))
                break;

            ++radius;
        }
        return radius;
    }

    public ExplosionSegment explosionSegmentAt(int x, int y) {
        for (int i = 0; i < _explosionSegments.length; i++) {
            if(_explosionSegments[i].getX() == x && _explosionSegments[i].getY() == y)
                return _explosionSegments[i];
        }
        return null;
    }

    @Override
    public void update() {

    }

    @Override
    public void render(Screen screen) {
        for(int i = 0; i < _explosionSegments.length; i++){
            _explosionSegments[i].render(screen);
        }
    }



    @Override
    public boolean collide(Entity e) {
        if(e instanceof Enemy){
            ((Enemy) e).killed();
            return false;
        }
        if(e instanceof Bomber){
            ((Bomber) e).killed();
            return false;
        }
        return true;
    }
}
