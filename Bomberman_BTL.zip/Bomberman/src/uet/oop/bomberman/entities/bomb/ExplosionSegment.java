package uet.oop.bomberman.entities.bomb;

import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.graphics.Screen;
import uet.oop.bomberman.graphics.Sprite;

public class ExplosionSegment extends Entity {
    protected boolean _last;
    public ExplosionSegment(int x, int y, int direction, boolean last){
        _x = x;
        _y = y;
        _last = last;
        switch(direction){
            case 0:
                if(!last) {
                    _sprite = Sprite.explosion_vertical2;
                } else {
                    _sprite = Sprite.explosion_vertical_top_last2;
                }
                break;
            case 1:
                if(!last) {
                    _sprite = Sprite.explosion_horizontal2;
                } else {
                    _sprite = Sprite.explosion_horizontal_right_last2;
                }
                break;
            case 2:
                if(!last) {
                    _sprite = Sprite.explosion_vertical2;
                } else {
                    _sprite = Sprite.explosion_vertical_down_last2;
                }
                break;
            case 3:
                if(!last) {
                    _sprite = Sprite.explosion_horizontal2;
                } else {
                    _sprite = Sprite.explosion_horizontal_left_last2;
                }
                break;
        }
    }

    @Override
    public void update() {

    }

    @Override
    public void render(Screen screen) {
        int x = (int) _x * 16;
        int y = (int) _y * 16;
        screen.renderEntity(x, y, this);
    }

    @Override
    public boolean collide(Entity e) {
        if(e instanceof Character){
            ((Character) e).killed();
            return false;
        }
        return true;
    }
}
