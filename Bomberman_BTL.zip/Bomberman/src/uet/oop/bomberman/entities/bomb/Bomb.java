package uet.oop.bomberman.entities.bomb;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.Level.Coordinates;
import uet.oop.bomberman.entities.AnimatedEntity;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Screen;
import uet.oop.bomberman.graphics.Sprite;

public class Bomb extends AnimatedEntity {

    protected double _timeToExplode = 120; //2 seconds
    public int _timeAfter = 20;

    protected Board _board;
    protected Explosion[] _explosion;
    protected boolean _exploded = false;
    protected boolean _allowedToPass = true;

    public Bomb(int x, int y, Board board){
        _x = x;
        _y = y;
        _board = board;
        _sprite = Sprite.bomb;
    }

    @Override
    public void update() {
        if(_timeToExplode > 0){
            _timeToExplode--;
        }
        else{
            if(!_exploded){
                explode();
            } else {
                updateExplosion();
            }
            if(_timeAfter > 0){
                _timeAfter--;
            } else {
                remove();
            }
        }
        animate();
    }

    @Override
    public void render(Screen screen) {

        if(_exploded) {
            _sprite =  Sprite.bomb_exploded2;
            renderExplosion(screen);
        } else
            _sprite = Sprite.movingSprite(Sprite.bomb, Sprite.bomb_1, Sprite.bomb_2, _animate, 60);

        int xt = (int) _x * 16;
        int yt = (int) _y * 16;

        screen.renderEntity(xt, yt , this);
    }

    public void renderExplosion(Screen screen){
        for(int i = 0; i < _explosion.length; i++){
            _explosion[i].render(screen);
        }
    }

    public void explode(){
        _exploded = true;
        Character a = _board.getCharacter((int)_x, (int) _y);
        if(a != null){
            a.killed();
        }
        _allowedToPass = false;
        _explosion = new Explosion[4];

        for(int i = 0; i < _explosion.length; i++){
            _explosion[i] = new Explosion((int)_x, (int)_y, i, Game.getBombRadius(), _board);
        }
    }

    public ExplosionSegment explosionAt(int x, int y){
        if(!_exploded) return null;
        for(int i = 0; i < _explosion.length; i++){
            if(_explosion[i] == null) return null;
            ExplosionSegment e = _explosion[i].explosionSegmentAt(x, y);
            if(e != null) return e;
        }
        return null;
    }

    public void updateExplosion(){
        for (int i = 0; i < _explosion.length; i++) {
            _explosion[i].update();
        }
    }

    @Override
    public boolean collide(Entity e) {
        if(e instanceof Bomber) {
            double diffX = e.getX() - Coordinates.tileToPixel(getX());
            double diffY = e.getY() - Coordinates.tileToPixel(getY());

            if(!(diffX >= -10 && diffX < 16 && diffY >= 1 && diffY <= 28)) _allowedToPass = false;

            return _allowedToPass;
        }
        if(e instanceof Explosion){
            _timeToExplode = 0;
            return true;
        }
        return false;
    }
}
