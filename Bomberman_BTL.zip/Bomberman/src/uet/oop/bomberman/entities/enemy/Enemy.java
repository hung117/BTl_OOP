package uet.oop.bomberman.entities.enemy;

import uet.oop.bomberman.Board;
import uet.oop.bomberman.Game;
import uet.oop.bomberman.Level.Coordinates;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.bomb.Explosion;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.Screen;
import uet.oop.bomberman.graphics.Sprite;

import java.awt.*;

public abstract class Enemy extends Character {

    protected int _points;
    protected double _speed;
    protected AI _ai;
    protected Sprite _deadSprite;

    protected final double MAX_STEPS;
    protected final double rest;
    protected double _steps;
    protected int _finalAnimation = 30;

    public Enemy(int x, int y, Board board, Sprite dead, double speed, int points){
        super(x, y, board);
        _x = x;
        _y = y;
        _board = board;
        _deadSprite = dead;
        _speed = speed;
        _points = points;

        MAX_STEPS = Game.TILES_SIZE / speed;
        rest = (MAX_STEPS - (int)MAX_STEPS) / MAX_STEPS;
        _steps = MAX_STEPS;
        _timeAfterDead = 20;
    }

    @Override
    public void update(){
        animate();
        if(!_alive){
            afterKill();
            return;
        }
        if(_alive){
            calculateMove();
        }
    }

    @Override
    public void render(Screen screen){
        if(_alive) {
            chooseSprite();
        } else {
            if (_timeAfterDead > 0) {
                _sprite = _deadSprite;
                _animate = 0;
            } else {
                _sprite = Sprite.movingSprite(Sprite.mob_dead1, Sprite.mob_dead2, Sprite.mob_dead3, _animate, 60);
            }
        }
        screen.renderEntity((int) _x, (int) _y - _sprite.SIZE, this);
    }

    @Override
    public boolean collide(Entity e) {
        if(e instanceof Bomber){
            ((Bomber) e).killed();
            return false;
        }
        if(e instanceof Explosion){
            killed();
            return false;
        }
        return true;
    }

    @Override
    protected void calculateMove() {
        int x = 0, y = 0;
        if(_steps <= 0){
            _direction = _ai.calculateDirection();
            _steps = MAX_STEPS;
        }
        if(_direction == 0) y--;
        if(_direction == 1) x++;
        if(_direction == 2) y++;

        if(_direction == 3) x--;
        if(canMove(x, y)) {
            _steps -= 1 + rest;
            move(x * _speed, y * _speed);
            _moving = true;
        } else {
            _steps = 0;
            _moving = false;
        }

    }

    @Override
    protected void move(double xa, double ya) {
        if(!_alive) return;
        _y += ya;
        _x += xa;
    }

    @Override
    public void killed() {
        if(!_alive) return;
        _alive = false;
        _board.addPoints(_points);
        //can add msg later
        Message msg = new Message("+" + _points, getXMessage(), getYMessage(), 2, Color.white, 14);
        _board.addMessage(msg);
    }

    @Override
    protected void afterKill() {
        if(_timeAfterDead > 0) --_timeAfterDead;
        else {
            if(_finalAnimation > 0) --_finalAnimation;
            else
                remove();
        }
    }

    @Override
    protected boolean canMove(double x, double y) {
        double xr = _x, yr = _y - Game.TILES_SIZE;

        if(_direction == 0) {
            yr += _sprite.getSize() -1 ;
            xr += _sprite.getSize() / 2;
        }
        if(_direction == 1) {
            yr += _sprite.getSize() / 2;
            xr += 1;
        }
        if(_direction == 2) {
            xr += _sprite.getSize() / 2;
            yr += 1;
        }
        if(_direction == 3) {
            xr += _sprite.getSize() -1;
            yr += _sprite.getSize() / 2;
        }

        int xx = Coordinates.pixelToTile(xr) +(int)x;
        int yy = Coordinates.pixelToTile(yr) +(int)y;

        Entity a = _board.getEntity(xx, yy, this);

        return a.collide(this);
    }

    protected abstract void chooseSprite();

}
