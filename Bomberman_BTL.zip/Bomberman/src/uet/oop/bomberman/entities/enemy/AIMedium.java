package uet.oop.bomberman.entities.enemy;

import uet.oop.bomberman.entities.player.Bomber;

public class AIMedium extends AI {
    Bomber _bomber;
    Enemy _e;
    private int distance;

    public AIMedium(Bomber bomber, Enemy e) {
        _bomber = bomber;
        _e = e;
    }

    @Override
    /**
     * return direction flag
     */
    public int calculateDirection() {
        distance = (int) Math.abs(Math.sqrt(Math.pow(_bomber.getXTile() - _e.getXTile(),2)+Math.pow(_bomber.getYTile() - _e.getYTile(),2)));

        if (distance > 4 || (_bomber == null)) {
            return rand.nextInt(4);
        }

        int vertical = rand.nextInt(2);

        if (vertical == 1) {
            int v = calculateRowDirection();
            if (v != -1)
                return v;
            else
                return calculateColDirection();

        } else {
            int h = calculateColDirection();

            if (h != -1)
                return h;
            else
                return calculateRowDirection();
        }
    }

    protected int calculateColDirection() {
        if (_bomber.getXTile() < _e.getXTile())
            return 3;
        else if (_bomber.getXTile() > _e.getXTile())
            return 1;

        return -1;
    }

    protected int calculateRowDirection() {
        if (_bomber.getYTile() < _e.getYTile())
            return 0;
        else if (_bomber.getYTile() > _e.getYTile())
            return 2;
        return -1;
    }
}
