package uet.oop.bomberman.entities.enemy;

public class AILow extends AI {

    @Override
    public int calculateDirection() {
        return rand.nextInt(4);
    }
}
