package uet.oop.bomberman;

import uet.oop.bomberman.Control.Keyboard;
import uet.oop.bomberman.Level.FileLevelLoader;
import uet.oop.bomberman.Level.LevelLoader;
import uet.oop.bomberman.entities.Character;
import uet.oop.bomberman.entities.Entity;
import uet.oop.bomberman.entities.Message;
import uet.oop.bomberman.entities.bomb.Bomb;
import uet.oop.bomberman.entities.bomb.ExplosionSegment;
import uet.oop.bomberman.entities.player.Bomber;
import uet.oop.bomberman.graphics.IRender;
import uet.oop.bomberman.graphics.Screen;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Board implements IRender {

    protected LevelLoader _levelLoader;
    protected Game _game;
    protected Keyboard _input;
    protected Screen _screen;

    public Entity[] _entities;
    public List<Character> _characters = new ArrayList<>();
    protected List<Bomb> _bombs = new ArrayList<>();
    private List<Message> _messages = new ArrayList<>();

    private int _screenToShow = -1; //1:endgame, 2:changelevel, 3:paused

    private int _time = Game.TIME;
    private int _points = Game.POINTS;
    private int _lives = Game.LIVES;

    public Board(Game game, Keyboard input, Screen screen) {
        _game = game;
        _input = input;
        _screen = screen;


        loadLevel(1);
    }

    @Override
    public void update() {
        if( _game.isPaused() ) return;


        updateCharacters();
        updateEntities();
        updateBombs();
        updateMessages();
        outOfTime();


        for (int i = 0; i < _characters.size(); i++) {
            Character a = _characters.get(i);
            if(a.isRemoved()) _characters.remove(i);
        }
    }

    @Override
    public void render(Screen screen) {
        if( _game.isPaused() ) return;

        //only render the visible part of screen
        int x0 = Screen.xOffset / 16; //tile precision, -> left X
        int x1 = (Screen.xOffset + screen.getWidth() + Game.TILES_SIZE) / Game.TILES_SIZE; // -> right X
        int y0 = Screen.yOffset / 16;
        int y1 = (Screen.yOffset + screen.getHeight()) / Game.TILES_SIZE; //render one tile plus to fix black margins

        for (int y = y0; y < y1; y++) {
            for (int x = x0; x < x1; x++) {
                _entities[x + y * _levelLoader.getWidth()].render(screen);
            }
        }
        renderBombs(screen);
        renderCharacter(screen);
    }

    public void loadLevel (int level) {
        // clear all before get the new status of whole
        _time = Game.TIME;
        _screenToShow = 2;
        _game.resetScreenDelay();
        _game.pause();
        _characters.clear();
        _bombs.clear();
        _messages.clear();

        try {
            _levelLoader = new FileLevelLoader(this, level);
            _entities = new Entity[_levelLoader.getHeight() * _levelLoader.getWidth()];

            _levelLoader.createEntities();
        } catch (Exception e) {
            endGame();
            System.out.println("LoadLevelException");
        }
    }

    /**
     * xử lí tương tác của ng chơi trong "Bomber"
     * @param e
     */
    public void addMessage(Message e) {
        _messages.add(e);
    }
    protected void updateEntities() {
        if( _game.isPaused() ) return;
        for (int i = 0; i < _entities.length; i++) {
            _entities[i].update();
        }
    }

    protected void outOfTime(){
        if(_time < 0){
            endGame();
        }
    }

    protected void updateBombs() {
        if( _game.isPaused() ) return;
        Iterator<Bomb> itr = _bombs.iterator();

        while(itr.hasNext())
            itr.next().update();
    }

    protected void updateMessages() {
        if( _game.isPaused() ) return;
        Message m;
        int left;
        for (int i = 0; i < _messages.size(); i++) {
            m = _messages.get(i);
            left = m.getDuration();

            if(left > 0)
                m.setDuration(--left);
            else
                _messages.remove(i);
        }
    }
    protected void updateCharacters() {
        if( _game.isPaused() ) return;
        Iterator<Character> itr = _characters.iterator();

        while(itr.hasNext() && !_game.isPaused())
            itr.next().update();
    }
    protected void renderCharacter(Screen screen) {
        Iterator<Character> itr = _characters.iterator();

        while(itr.hasNext())
            itr.next().render(screen);
    }

    protected void renderBombs(Screen screen) {
        Iterator<Bomb> itr = _bombs.iterator();

        while(itr.hasNext())
            itr.next().render(screen);
    }
    public void renderMessages(Graphics g) {
        Message m;
        for (int i = 0; i < _messages.size(); i++) {
            m = _messages.get(i);

            g.setFont(new Font("Arial", Font.PLAIN, m.getSize()));
            g.setColor(m.getColor());
            g.drawString(m.getMessage(), (int)m.getX() - Screen.xOffset  * Game.SCALE, (int)m.getY());
        }
    }


    public void drawScreen(Graphics g) {
        switch (_screenToShow) {
            case 1:
                _screen.drawEndGame(g, _points);
                break;
            case 2:
                _screen.drawChangeLevel(g, _levelLoader.getLevel());
                break;
            case 3:
                _screen.drawPaused(g);
                break;
        }
    }

    public Entity getEntity(double x, double y, Character c){
        Entity res = null;

        res = getExplosionSegmentAt((int)x, (int)y);
        if( res != null) return res;

        res = getBombAt((int) x,(int) y);
        if( res != null) return res;

        res = getCharacterAtExcluding((int)x, (int)y, c);
        if( res != null) return res;

        res = getEntityAt((int)x, (int)y);

        return res;
    }

    public Bomb getBombAt(int x, int y){
        Iterator<Bomb> bs = _bombs.iterator();
        Bomb b;
        while(bs.hasNext()) {
            b = bs.next();
            if(b.getX() == x && b.getY() == y)
                return b;
        }

        return null;
    }

    public ExplosionSegment getExplosionSegmentAt(int x, int y){
        Iterator<Bomb> bs = _bombs.iterator();
        Bomb b;
        while(bs.hasNext()) {
            b = bs.next();

            ExplosionSegment e = b.explosionAt(x, y);
            if(e != null) {
                return e;
            }
        }

        return null;
    }
    public boolean detectNoEnemies() {
        int total = 0;
        for (int i = 0; i < _characters.size(); i++) {
            if(_characters.get(i) instanceof Bomber == false)
                ++total;
        }

        return total == 0;
    }
    public Bomber getBomber() {
        Iterator<Character> itr = _characters.iterator();

        Character cur;
        while(itr.hasNext()) {
            cur = itr.next();

            if(cur instanceof Bomber)
                return (Bomber) cur;
        }

        return null;
    }
    public Character getCharacter(int x, int y){
        Iterator itr = this._characters.iterator();

        Character cur;
        do {
            if (!itr.hasNext()) {
                return null;
            }

            cur = (Character) itr.next();
        } while((double)cur.getXTile() != x || (double)cur.getYTile() != y);

        return cur;
    }

    public Character getCharacterAtExcluding(int x, int y, Character a) {
        Iterator<Character> itr = _characters.iterator();

        Character cur;
        while(itr.hasNext()) {
            cur = itr.next();
            if(cur == a) {
                continue;
            }

            if(cur.getXTile() == x && cur.getYTile() == y) {
                return cur;
            }

        }

        return null;
    }


    //add
    public void addEntity(int pos, Entity e) {
        _entities[pos] = e;
    }

    public void addCharacter(Character c){
        _characters.add(c);
    }

    public void addBomb(Bomb e){
        _bombs.add(e);
    }

    //get
    public Entity getEntityAt(double x, double y) {
        return _entities[(int)x + (int)y * _levelLoader.getWidth()];
    }

    public List<Bomb> getBombs(){
        return _bombs;
    }

    public Keyboard getInput() {
        return _input;
    }

    public LevelLoader getLevel() {
        return _levelLoader;
    }
    //lives
    public int getLives() {
        return _lives;
    }
    public void addLives(int lives) {
        this._lives += lives;
    }
    //time
    public int getTime() {
        return _time;
    }
    public int subtractTime(){
        return _time--;
    }
    //points
    public int getPoints() {
        return _points;
    }
    public void addPoints(int points) {
        this._points += points;
    }


    public Game getGame() {
        return _game;
    }

    /**
     * get screen to show
     * @return _screenToShow
     */
    public int getShow() {
        return _screenToShow;
    }

    public int getHeight() {
        return _levelLoader.getHeight();
    }

    public int getWidth() {
        return _levelLoader.getWidth();
    }

    public void endGame() {
        _screenToShow = 1;
        _game.resetScreenDelay();
        _game.pause();
    }

    public void restartLevel() {
        loadLevel(_levelLoader.getLevel());
    }
}

