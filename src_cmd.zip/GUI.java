import java.sql.SQLOutput;

public class GUI {
    /**
     * cons_des.
     */
    public GUI() {

        System.out.println("\n" + "Dictionary: ");
        System.out.println("0. insert Word_array: ");
        System.out.println("1. get Word_array from FILE: ");
        System.out.println("2. searchWord ");
        System.out.println("3. addWord ");
        System.out.println("4. deleteWord");
        System.out.println("5. show All");
        System.out.println("6. quit " + "\n");


    }

    ;
}
