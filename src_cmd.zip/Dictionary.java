public class Dictionary{
    public Word[] Arr_Dictionary = new Word[0];

    protected String[] target = new String[0];
    protected String[] explain = new String[0];
    protected String[] prounounce = new String[0];

    protected String newTargetWord;
    protected String newExplainWord;
    protected String newPronounce;


}